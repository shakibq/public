package com.example.raha.mokhche;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RegGuest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_guest);
    }
}
